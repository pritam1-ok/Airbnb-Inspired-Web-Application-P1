
const express = require("express");
const Property = require("../models/Property");

const router = express.Router();

router.post("/", async (req, res) => {
  const property = await Property.create(req.body);
  res.json(property);
});

router.get("/", async (req, res) => {
  const properties = await Property.find();
  res.json(properties);
});

module.exports = router;
