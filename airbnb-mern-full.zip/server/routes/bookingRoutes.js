
const express = require("express");
const Booking = require("../models/Booking");

const router = express.Router();

router.post("/", async (req, res) => {
  const booking = await Booking.create(req.body);
  res.json(booking);
});

module.exports = router;
