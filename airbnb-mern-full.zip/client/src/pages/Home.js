
import React, { useEffect, useState } from "react";
import axios from "axios";

export default function Home() {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/properties")
      .then(res => setData(res.data));
  }, []);

  return (
    <div>
      <h2>Properties</h2>
      {data.map(p => <div key={p._id}>{p.title} - ₹{p.price}</div>)}
    </div>
  );
}
